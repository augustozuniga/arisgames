-- MySQL dump 10.11
--
-- Host: localhost    Database: arisv1
-- ------------------------------------------------------
-- Server version	5.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `159_folder_contents`
--

DROP TABLE IF EXISTS `159_folder_contents`;
CREATE TABLE `159_folder_contents` (
  `object_content_id` int(10) unsigned NOT NULL auto_increment,
  `folder_id` int(10) unsigned NOT NULL default '0',
  `content_type` enum('Node','Item','Npc') collate utf8_unicode_ci NOT NULL default 'Node',
  `content_id` int(10) unsigned NOT NULL default '0',
  `previous_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`object_content_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `159_folder_contents`
--

LOCK TABLES `159_folder_contents` WRITE;
/*!40000 ALTER TABLE `159_folder_contents` DISABLE KEYS */;
INSERT INTO `159_folder_contents` VALUES (8,0,'Npc',7,6),(2,0,'Npc',1,0),(3,0,'Npc',2,1),(4,0,'Npc',3,2),(5,0,'Npc',4,3),(6,0,'Npc',5,4),(7,0,'Npc',6,5),(10,0,'Npc',9,7),(11,0,'Npc',10,8),(12,0,'Npc',11,9),(13,0,'Npc',12,10),(14,0,'Npc',13,11),(15,0,'Npc',14,12),(16,0,'Npc',15,13);
/*!40000 ALTER TABLE `159_folder_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `159_folders`
--

DROP TABLE IF EXISTS `159_folders`;
CREATE TABLE `159_folders` (
  `folder_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL default '0',
  `previous_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`folder_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `159_folders`
--

LOCK TABLES `159_folders` WRITE;
/*!40000 ALTER TABLE `159_folders` DISABLE KEYS */;
/*!40000 ALTER TABLE `159_folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `159_items`
--

DROP TABLE IF EXISTS `159_items`;
CREATE TABLE `159_items` (
  `item_id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `icon_media_id` int(10) unsigned NOT NULL default '0',
  `media_id` int(10) unsigned NOT NULL default '0',
  `dropable` enum('0','1') collate utf8_unicode_ci NOT NULL default '0',
  `destroyable` enum('0','1') collate utf8_unicode_ci NOT NULL default '0',
  `origin_timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `creator_player_id` int(10) unsigned NOT NULL default '0',
  `origin_latitude` double NOT NULL default '0',
  `origin_longitude` double NOT NULL default '0',
  PRIMARY KEY  (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `159_items`
--

LOCK TABLES `159_items` WRITE;
/*!40000 ALTER TABLE `159_items` DISABLE KEYS */;
INSERT INTO `159_items` VALUES (1,'Intro video','In this situated documentary you roleplay as a reporter assigned to cover the anti-Dow protests taking place at UW on October 17-18, 1967. After viewing the video click on the GPS tab in order to locate your editor. He will give you your first lead. ',0,1,'0','0','2010-06-02 22:16:35',0,0,0),(2,'Protest Flyer','All of the interviews and documents that appear in Dow Day are based on archival documents found at the Wisconsin State Historical Society Library. For example, this flyer is an excerpt from an actual flyer that was handed out in October of 1967.',0,14,'0','0','2010-06-02 22:30:12',0,0,0),(3,'Marchers - Bascom','As you look down Bascom Hill you can see about 200 to 250 protestors marching towards you.',0,2,'0','0','2010-05-11 21:57:33',0,0,0),(4,'Inside Commerce','There is a stream of students entering the Commerce building. When you first enter there are about 40 protestors in the hallway. Within minutes the hallway becomes packed with people, including protestors, observers, police officers, cameramen, news reporters, University officials, and students trying to get to class. It is hard to navigate your way through the crowd.',0,3,'0','0','2010-06-03 22:09:59',0,0,0),(5,'Police Arriving','Look towards the parking lot that is located across the street. As you observe the crowd from this position you notice that a series of police cars begin pulling into the parking lot across the street.',0,5,'0','0','2010-05-11 23:27:33',0,0,0),(6,'Police enter Commerce','The scene in front of you is chaotic. The police officers are using their clubs to force the demonstrators out of the building. Some of the demonstrators are fighting back.',0,7,'0','0','2010-06-03 23:12:47',0,0,0),(7,'Teargas','The police begin firing off teargas in order to break up the demonstration.\r\nThis marks the first time that teargas has been used against the students at the UW.',0,6,'0','0','2010-05-11 23:28:06',0,0,0),(8,'Soglin','An interview with Paul Soglin.',0,4,'0','0','2010-05-11 23:35:29',0,0,0),(9,'Faculty Resolution','',0,15,'0','0','2010-05-14 18:43:08',0,0,0),(10,'Test','',0,212,'1','1','2010-05-14 22:46:46',98,37.331719,-122.006432),(11,'Long audio','',0,217,'1','1','2010-05-20 20:20:11',100,43.152638,-89.404495),(12,'Not allowed','',0,219,'','1','2010-05-22 04:41:26',128,43.096256,-89.354686),(13,'','',0,220,'0','1','2010-05-24 12:15:51',110,-33.492684,151.31959),(14,'Testing','Retry',0,221,'0','1','2010-05-28 20:04:48',94,40.421501,-105.002687),(15,'Roy','Making chile',0,222,'0','1','2010-05-28 20:06:17',94,40.421441,-105.002704),(16,'Chris','',0,229,'0','1','2010-06-12 20:44:04',100,43.075739,-89.399355),(17,'One two three','Four',0,230,'0','1','2010-06-17 20:24:34',310,53.315132,-6.31585),(18,'CD','DVD',0,231,'0','1','2010-06-17 20:38:27',310,1,53.315132),(19,'Test','Test',0,236,'0','1','2010-06-30 23:15:25',98,37.331714,-122.00663),(20,'Dow Day Redux','',0,238,'0','1','2010-07-12 03:48:38',385,28.801625,-81.686991),(21,'Yyyy','',0,242,'0','1','2010-07-29 08:34:07',412,22.542902,114.072672),(22,'Jjjj','',0,243,'0','1','2010-07-29 08:34:37',412,22.542902,114.072672),(23,'Hall','',0,244,'0','1','2010-08-02 22:09:28',419,44.952463,-93.106852),(24,'Test','',0,245,'0','1','2010-08-02 22:10:12',419,44.950362,-93.107147);
/*!40000 ALTER TABLE `159_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `159_locations`
--

DROP TABLE IF EXISTS `159_locations`;
CREATE TABLE `159_locations` (
  `location_id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` tinytext collate utf8_unicode_ci NOT NULL,
  `latitude` double NOT NULL default '43.0746561',
  `longitude` double NOT NULL default '-89.384422',
  `error` double NOT NULL default '5',
  `type` enum('Node','Event','Item','Npc') collate utf8_unicode_ci NOT NULL,
  `type_id` int(11) NOT NULL,
  `icon_media_id` int(10) unsigned NOT NULL default '0',
  `item_qty` int(11) NOT NULL default '0',
  `hidden` enum('0','1') collate utf8_unicode_ci NOT NULL default '0',
  `force_view` enum('0','1') collate utf8_unicode_ci NOT NULL default '0',
  PRIMARY KEY  (`location_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `159_locations`
--

LOCK TABLES `159_locations` WRITE;
/*!40000 ALTER TABLE `159_locations` DISABLE KEYS */;
INSERT INTO `159_locations` VALUES (2,'Editor','',43.076014654537,-89.399642451567,25,'Npc',1,0,1,'0','0'),(3,'Dow Recruiter','',43.07550842555,-89.399381822662,25,'Npc',2,0,1,'0','0'),(4,'Protestor','',43.074933,-89.400438,25,'Npc',3,0,1,'0','0'),(5,'State Legislator','',43.074868061524,-89.402136196317,25,'Npc',4,0,1,'0','0'),(6,'Marchers - Bascom','',43.075296413877,-89.403374183615,25,'Node',22,0,1,'0','0'),(7,'Mary','',43.074997865584,-89.404967573966,25,'Npc',7,0,1,'0','0'),(8,'Dow Interviewee 1','',43.076057921778,-89.405690226839,25,'Npc',9,0,1,'0','0'),(9,'Dow Interviewee 2','',43.076243970565,-89.405512525313,25,'Npc',10,0,1,'0','0'),(10,'UW Police Chief','',43.076033,-89.40484,25,'Npc',11,0,1,'0','0'),(11,'Madison Police Chief','',43.076018,-89.405145,50,'Npc',12,0,1,'0','0'),(12,'UW Student Leader','',43.075742070217,-89.405204509334,25,'Npc',13,0,1,'0','0'),(13,'State Legislator 2','',43.07556,-89.403571,25,'Npc',14,0,1,'0','0'),(14,'Editor 2','',43.07556,-89.403571,25,'Npc',15,0,1,'0','0'),(22,'Bascom Hall','where you meet dean kaufman',43.075381,-89.403632,25,'Npc',6,0,1,'0','0'),(15,'Inside Commerce','',43.07531,-89.405285,5,'Node',23,0,1,'0','0'),(16,'Outside Commerce','',43.075875,-89.40536,25,'Node',24,0,0,'0','0'),(17,'police enter commerce','the plaque. appears after player sees the video.',43.075777,-89.405242,50,'Node',25,0,0,'1','0'),(18,'Police Officer','',43.075777,-89.405242,25,'Npc',16,0,1,'0','0'),(19,'Student 3','',43.075777,-89.405242,25,'Npc',17,0,1,'0','0'),(20,'Teargas','',43.075865,-89.404474,25,'Node',26,0,1,'0','0'),(21,'Flag','',43.075697,-89.403935,25,'Node',27,0,1,'0','0'),(1,'Intro video','',43.076014654537,-89.399642451567,1e+37,'Node',29,0,80,'1','1'),(23,'police arriving','video location. This makes Madison chief appear.',43.076053595055,-89.405364440707,25,'Item',5,0,98,'0','0'),(24,'police enter commerce','video',43.075777,-89.405242,25,'Item',6,0,98,'0','1'),(25,'Entering Commerce','what the player triggers and sees on the map',43.075445,-89.405105,25,'Node',28,0,1,'0','0');
/*!40000 ALTER TABLE `159_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `159_nodes`
--

DROP TABLE IF EXISTS `159_nodes`;
CREATE TABLE `159_nodes` (
  `node_id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) collate utf8_unicode_ci NOT NULL,
  `text` text collate utf8_unicode_ci,
  `opt1_text` varchar(100) collate utf8_unicode_ci default NULL,
  `opt1_node_id` int(11) unsigned NOT NULL default '0',
  `opt2_text` varchar(100) collate utf8_unicode_ci default NULL,
  `opt2_node_id` int(11) unsigned NOT NULL default '0',
  `opt3_text` varchar(100) collate utf8_unicode_ci default NULL,
  `opt3_node_id` int(11) unsigned NOT NULL default '0',
  `require_answer_incorrect_node_id` int(11) unsigned NOT NULL default '0',
  `require_answer_string` varchar(50) collate utf8_unicode_ci default NULL,
  `require_answer_correct_node_id` int(10) unsigned NOT NULL default '0',
  `media_id` int(10) unsigned NOT NULL default '0',
  `icon_media_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`node_id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `159_nodes`
--

LOCK TABLES `159_nodes` WRITE;
/*!40000 ALTER TABLE `159_nodes` DISABLE KEYS */;
INSERT INTO `159_nodes` VALUES (1,'editor','<dialog>\r\n<npc zoomX=\'15\' zoomY=\'15\' zoomWidth=\'290\' zoomHeight=\'386\' zoomTime=\'5\'>\r\nYou should have time to do a couple of interviews before the protests start.  Try to get the story from a few different perspectives. Here is your first lead... Why don\'t you start by heading up to the Chancellor\'s office in Bascom Hall...  \r\n</npc>\r\n<pc>\r\nI\'ll get right on it.\r\n</pc>\r\n<npc zoomX=\'15\' zoomY=\'15\' zoomWidth=\'290\' zoomHeight=\'386\' zoomTime=\'5\'>\r\nHey wait! See that guy across the street in Library Mall? No, the one with the black overcoat. He is one of the recruiters from Dow. I ran into him yesterday, but he did not have time for an interview.\r\n</npc>\r\n<npc>\r\nHe is talking to one of the reporters from the Daily Cardinal. Why don\'t you run over there and see if you can get any information out of him.\r\n</npc>\r\n<pc>\r\nI\'m on my way.\r\n</pc>\r\n<npc>\r\nWhen you\'re done don\'t forget to head up to the Chancellor\'s office. Hurry and we\'ll see you later. Good Luck.\r\n</npc>\r\n</dialog>','',0,'',0,'',0,0,'',0,0,0),(2,'Current','I am heading up to the Commerce building to get ready for the job interviews that we are conducting. ',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(3,'about protests','<dialog>\r\n<pc>\r\nHow do you think the University should handle the protests?\r\n</pc>\r\n<npc>\r\nI think that the UW has a responsibility to make sure that things go smoothly. We are guests here and there are students who would like to work for us. Don\'t they have a right to interview for a job? They should definitely not have to fight their way through a crowd to get to an interview.\r\n</npc>\r\n</dialog> ',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(4,'dow\'s role','<dialog>\r\n<pc>\r\nHow do you answer concerns over Dow\'s role in the production of Napalm?\r\n</pc>\r\n<npc>\r\nThe student protests against napalm are misguided. As a company we are being asked to make napalm for the military. It is our obligation to do so. \r\n</npc>\r\n<pc>\r\nDon\'t you profit from this business though?\r\n</pc>\r\n<npc>\r\nWe make napalm out of responsibility, not for profit. This is not a money making proposition for us.\r\n</npc>\r\n</dialog>',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(6,'why protesting','<dialog>\r\n<npc>\r\nBecause I am against Dow and other companies coming to the UW to recruit workers for the war effort. It is time for the students to take action and it is time for the administration to listen to the students. \r\n</npc>\r\n<pc>\r\nSure, but why single out Dow? \r\n</pc>\r\n<npc>\r\nBecause Dow makes napalm and I don\'t support companies who aid the war effort. It is pretty simple - allowing Dow onto campus is the same as supporting the war and the University should not be in the war business. \r\n</npc>\r\n<npc>\r\nHere, have a flyer. See you at the rally!\r\n</npc>\r\n</dialog>',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(7,'senator\'s role','I decided to walk down here from the Capitol to see how the university is going to handle things today. This is a public university and I have a responsibility as a politician to make sure that the public\'s money is being spent wisely.',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(8,'senator on protestors','I called Chancellor Sewell yesterday and told him that he was being too easy on the protesters. We can\'t have a small group of radical students running the show around here. The show they are putting on is a disgrace to our soldiers in Vietnam and to the great state of Wisconsin. ',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(9,'canceling interviews','<dialog>\r\n<pc>\r\nWhy doesn\'t the University simply cancel the Dow interviews? \r\n</pc>\r\n<npc>\r\nWe invited Dow onto this campus and they are our guests. They are providing a service to our students. If a student wants to interview for a job at Dow or any other company that comes to campus, then they have a right to do so. \r\n</npc>\r\n</dialog>',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(10,'handle protestors','<dialog>\r\n<pc>\r\nHow does the administration plan on handling the demonstrators? \r\n</pc>\r\n<npc>\r\nThe University has already established rules that prohibit students from disrupting University functions or the operations of companies who have been invited here. These rules were passed by the faculty last year after students disrupted the speech by Robert Kennedy. Look over the faculty documents. These state our position quite clearly. \r\n</npc>\r\n</dialog>',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(11,'Mary','<dialog>\r\n<npc>\r\nMy name is Mary and I am a UW student. No, I prefer not to give my last name. I don\'t want my parents to know that I was anywhere near the protests. \r\n</npc>\r\n<pc>\r\nHow do you feel about the protests?\r\n</pc>\r\n<npc>\r\nI am against the war, but I don\'t think that the protests are productive. I also don\'t think that the students should disrupt classes in order to make their point. I have a right to go to my classes. \r\n</npc>\r\n<npc>\r\nI have a class in the Commerce building today, but I am not sure that I want to fight my way in there. My main goal is to graduate, but these protests make it that much harder. I\'m heading over there now to see if I can get into the building.\r\n</npc>\r\n</dialog>',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(12,'student 1','<dialog>\r\n<npc>\r\nI tried to get in, but I couldn\'t because the hallway was packed and students blocked the door to room 104 where the interviews were taking place. I am graduating in January and Dow contacted me. If I don\'t get in while they are on campus I may miss the opportunity to interview with them. I don\'t understand why Dow is being singled out. There are other companies that do government work.\r\n</npc>\r\n</dialog>',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(13,'student 2','Yeah, but not in the napalm department. I was able to get into the interview room despite the fact that there were students protesting outside the door. It is not my job to decide whether they make napalm or not. \r\nAt the moment I really need to find a job. I have a right to have an interview if I want one.',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(14,'uw police chief','<dialog>\r\n<npc>\r\nI was just in the Chancellor\'s office and I filled him in on the situation in the Commerce building. I told him that communication between University authorities and the protestors has broken down and that the small number of officers in the Commerce building can\'t be expected to maintain order.\r\n</npc>\r\n<pc>\r\nWhat about the Chancellor?\r\n</pc>\r\n<npc>\r\nThe Chancellor maintains that the demonstration is an unlawful assembly and he wants something done. Unfortunately, the students are not responding to our requests to leave the building. \r\n</npc>\r\n<pc>\r\nSounds serious\r\n</pc>\r\n<npc>\r\nAs a result, the Chancellor authorized me to call for backup. I just got off the phone with Chief Emery from the Madison Police Department and his men should be here any minute. \r\n</npc>\r\n<pc>\r\nAny chance this will end peacefully?\r\n</pc>\r\n<npc>\r\nAs I was leaving I noticed that a couple of the student leaders were heading into the Chancellor\'s office. Hopefully, something can still be worked out. \r\n</npc>\r\n</dialog>',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(15,'madison chief','<dialog>\r\n<pc>\r\nIsn\'t it unusual for Madison police to be on campus? Why are you here?\r\n</pc>\r\n<npc>\r\nWe are here because the University called us in. We brought paddy wagons and we are prepared to make arrests if we need to. We are waiting for a decision from the University officials before we make our way in.\r\nApparently they are still meeting with some students who are representing the protestors.\r\n</npc>\r\n</dialog>',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(16,'student meeting with chancellor','<dialog>\r\n<npc>\r\nI just got done talking with Chancellor Sewell. I told him that if he signed a statement directing Dow to leave the UW campus and never return that we would end the sit-in. \r\n</npc>\r\n<pc>\r\nWhat did Chancellor Sewell do?\r\n</pc>\r\n<npc>\r\nHe said, \"No Deal.\" He said that he had to enforce the University\'s regulations. He also said, \"You guys better get out of that building, because people are going to come in and get you out if you don\'t.\" \r\n</npc>\r\n<pc>\r\nWhat now?\r\n</pc>\r\n<npc>\r\nThings are in his hands now.\r\n</npc>\r\n</dialog>',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(17,'police violence','I saw one of our officers get hit with a brick or a heavy shoe. It broke his nose and knocked him unconscious. Our guys were trying to defend themselves against this mob. The look of anger in these students\' eyes was unbelievable.',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(18,'student violence','They grabbed me and started beating me, and I ended up right on the floor. I don\'t know how long it lasted. One of them hit me right on the base of the spine. I was on my side, and instinctively my arms went out and my legs went out. And then they started working on my legs and my head. One cop asked me, \"Have you had enough?\" Then they picked me up and threw me forward.	',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(19,'legislator protest','I was up at the Commerce building to see how the University was going to handle the protestors. Those students are a disgrace to the university and to their country. They should be kicked out of school for what they did today.',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(20,'legislator blame','The University was way too easy on earlier demonstrations. If they had been tougher this never would have happened.',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(21,'done','I guess we got our lead story for tonight\'s paper. Head to the front steps of the Union and I will meet you there. We can talk a little about what happened before you write your article.',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(22,'Marchers ','As you look down Bascom Hill you can see about 200 to 250 protestors marching towards you. As the protestors begin to get closer you can hear them chanting, \"Dow must go!\" and playing various musical instruments. Chief Hanson, the head of University Protection and Security is accompanying the group up the hill. As the group passes it becomes apparent that they are heading towards the Commerce building.',NULL,0,NULL,0,NULL,0,0,NULL,0,2,0),(23,'Inside Commerce','There is a stream of students entering the Commerce building. When you first enter there are about 40 protestors in the hallway. Within minutes the hallway becomes packed with people, including protestors, observers, police officers, cameramen, news reporters, University officials, and students trying to get to class. It is hard to navigate your way through the crowd.\r\nYou see a professor talking to one of the University administrators. He is complaining that the noise level is too loud and is disturbing his class. You also see a professor telling Chief Hanson that he and his students can\'t get to their classroom. Eventually, despite difficulty getting through the crowd, Chief Hanson successfully escorts the professor and his students to their class. At first the protestors allow people to navigate through the hallway. As time goes on, however, they begin blocking any movement in the hallway. Chief Hanson and the UW administrators make several requests for the protestors to make a clearing so that other students can make their way through. The protestors refuse despite the fact that they are informed that they are in violation of University rules and risk being arrested. A student, who wants to get through to room 102 for an interview, asks one of the UW officials to escort him through the crowd. The official asks the protestors to let the student through, but they refuse. When the student attempts to make the passage anyway, one of the protestors grabs him around the neck and holds him. The student eventually leaves without getting an interview. Eventually, after several warnings, Chief Hanson orders the arrest of three protestors who are sitting directly in front of room 102. When the officers reach down to make the arrests, however, the three protestors call out for others to hold onto them. This makes it hard for the officers to make the arrests. Chief Hanson eventually calls off the arrests and tells the three that they will be dealt with at a later point.',NULL,0,NULL,0,NULL,0,0,NULL,0,18,0),(24,'Outside Commerce','The crowd outside Commerce has grown much larger. There are now about 1,000 people present. Not all of them are protestors, however. There are also students coming to and from classes, other news reporters and photographers, curious onlookers, and Dow supporters.',NULL,0,NULL,0,NULL,0,0,NULL,0,26,0),(25,'Police Enter Commerce','You see Chief Hansen at the entrance of the Commerce building speaking into a bullhorn. \"This is an unlawful assembly. We are going to clear the place out.\" The police form a wedge and begin entering the building.\r\nThe scene in front of you is chaotic. The police officers are using their clubs to force the demonstrators out of the building. Some of the demonstrators are fighting back.',NULL,0,NULL,0,NULL,0,0,NULL,0,27,0),(26,'Teargas','The police begin firing off teargas in order to break up the demonstration.\r\nThis marks the first time that teargas has been used against the students at the UW. As you head back down the hill your eyes begin stinging from the teargas that is hanging in the air.',NULL,0,NULL,0,NULL,0,0,NULL,0,28,0),(27,'Flag on Bascom','Look at the flag flying on top of Bascom Hall. As you make your way back towards State Street you see some people pointing up the hill towards the roof of Bascom Hall.\r\nAs you look at the roof of Bascom Hall you see a college-aged male cut the flag from the flagpole and run away.',NULL,0,NULL,0,NULL,0,0,NULL,0,29,0),(28,'Entering Commerce','Make your way into the Commerce Building  (now Ingraham). Find the nook where a payphone used to be (Hint: look next to the Women\'s Studies office). Across from the nook is one of the rooms where the Dow interviews were scheduled to take place. What is the room number? Click on the Decoder tab in ARIS and enter this number.\r\n',NULL,0,NULL,0,NULL,0,0,NULL,0,0,0),(29,'Intro Video','In this situated documentary you roleplay as a reporter assigned to cover the anti-Dow protests taking place at UW on October 17-18, 1967. After viewing the video click on the GPS tab in order to locate your editor. He will give you your first lead. \r\n',NULL,0,NULL,0,NULL,0,0,NULL,0,1,0);
/*!40000 ALTER TABLE `159_nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `159_npc_conversations`
--

DROP TABLE IF EXISTS `159_npc_conversations`;
CREATE TABLE `159_npc_conversations` (
  `conversation_id` int(11) NOT NULL auto_increment,
  `npc_id` int(10) unsigned NOT NULL default '0',
  `node_id` int(10) unsigned NOT NULL default '0',
  `text` tinytext collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`conversation_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `159_npc_conversations`
--

LOCK TABLES `159_npc_conversations` WRITE;
/*!40000 ALTER TABLE `159_npc_conversations` DISABLE KEYS */;
INSERT INTO `159_npc_conversations` VALUES (1,1,1,'Ok boss. Let\'s get started!'),(3,2,3,'The protests'),(4,2,4,'Napalm concerns'),(5,3,6,'Why are you protesting?'),(6,4,7,'Why are you on campus? '),(7,4,8,'How should the UW handle the protesters? '),(8,6,9,'Canceling Dow interviews'),(9,6,10,'Handling the protesters'),(10,7,11,'Who are you?'),(11,9,12,'What happened?'),(12,10,13,'Really?'),(13,11,14,'What\'s happening?'),(14,12,15,'Unusual presence'),(15,13,16,'Meeting?'),(16,16,17,'Violence'),(17,17,18,'Violence'),(18,14,19,'Protestors'),(19,14,20,'Blame'),(20,15,21,'done');
/*!40000 ALTER TABLE `159_npc_conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `159_npcs`
--

DROP TABLE IF EXISTS `159_npcs`;
CREATE TABLE `159_npcs` (
  `npc_id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` tinytext collate utf8_unicode_ci NOT NULL,
  `text` tinytext collate utf8_unicode_ci NOT NULL,
  `media_id` int(10) unsigned NOT NULL default '0',
  `icon_media_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`npc_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `159_npcs`
--

LOCK TABLES `159_npcs` WRITE;
/*!40000 ALTER TABLE `159_npcs` DISABLE KEYS */;
INSERT INTO `159_npcs` VALUES (1,'Editor','','Hey, sorry to rush you like this, but it looks like things are heating up on Bascom Hill and we need a story for tonight\'s paper. ',8,0),(2,'Dow Recruiter','','Sure, I can answer a couple of questions, but they have to be fast because I am heading up to the Commerce building to get ready for the job interviews I am conducting. ',9,0),(3,'Protestor','','Dow Rally at 10:30! Dow Rally at 10:30! Sure, I can answer a few questions. Wait, you don\'t write for the Badger Herald do you? ',10,0),(4,'State Legislator','','I\'d be happy to give you a quote.',12,0),(6,'Dean Kauffman','','The Chancellor is in the middle of meetings right now, so he asked me to come out to talk to the press.',11,0),(7,'Mary','','Yes, you can ask me a few questions.',16,0),(9,'Student 1','','Yeah, I wanted to interview with Dow.',20,0),(10,'Student 2','','I\'m looking for a job at Dow',21,0),(11,'UW Police Chief','','I\'m Chief Hanson from University Police and Security',19,0),(12,'Chief Emery','','I\'m Chief Emery of the Madison Police Department.',25,0),(13,'UW Student Leader','','I just met with Chancellor Sewell',22,0),(14,'State Legislator','','Hi again. I was just up at the Commerce building.',12,0),(15,'Editor','','Hey you made it out of there!',8,0),(16,'Police Officer','','This is unbelievable!',23,0),(17,'Student 3','','This is wrong!',24,0);
/*!40000 ALTER TABLE `159_npcs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `159_player_items`
--

DROP TABLE IF EXISTS `159_player_items`;
CREATE TABLE `159_player_items` (
  `id` int(11) NOT NULL auto_increment,
  `player_id` int(11) unsigned NOT NULL default '0',
  `item_id` int(11) unsigned NOT NULL default '0',
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `unique` (`player_id`,`item_id`),
  KEY `player_id` (`player_id`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=636 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `159_player_items`
--

LOCK TABLES `159_player_items` WRITE;
/*!40000 ALTER TABLE `159_player_items` DISABLE KEYS */;
INSERT INTO `159_player_items` VALUES (33,104,1,'2010-05-17 11:32:47'),(71,129,1,'2010-05-20 22:28:22'),(31,98,1,'2010-05-14 22:46:11'),(32,98,10,'2010-05-14 22:46:46'),(327,286,1,'2010-06-12 04:37:30'),(114,169,1,'2010-05-28 17:02:41'),(356,109,9,'2010-06-14 14:45:36'),(42,117,1,'2010-05-18 19:24:27'),(41,115,1,'2010-05-18 02:27:22'),(132,172,1,'2010-05-31 14:45:03'),(117,167,2,'2010-05-28 17:27:02'),(43,121,1,'2010-05-18 21:36:32'),(44,125,1,'2010-05-19 09:20:54'),(179,128,4,'2010-06-03 21:29:07'),(326,189,1,'2010-06-11 20:30:34'),(293,99,1,'2010-06-10 21:52:43'),(51,85,1,'2010-05-20 19:13:06'),(121,167,3,'2010-05-28 17:31:04'),(70,128,1,'2010-05-20 22:25:35'),(354,109,2,'2010-06-14 14:41:33'),(119,166,2,'2010-05-28 17:29:57'),(115,167,1,'2010-05-28 17:11:02'),(72,130,1,'2010-05-20 22:28:38'),(171,156,3,'2010-06-03 19:28:14'),(116,166,1,'2010-05-28 17:11:11'),(133,174,1,'2010-06-01 14:09:06'),(79,129,2,'2010-05-20 22:43:12'),(240,217,1,'2010-06-09 16:20:14'),(81,130,2,'2010-05-20 22:43:22'),(82,128,2,'2010-05-20 22:43:26'),(172,156,9,'2010-06-03 19:30:05'),(84,128,3,'2010-05-20 22:51:28'),(514,444,2,'2010-08-13 11:09:51'),(86,129,3,'2010-05-20 22:51:41'),(87,130,3,'2010-05-20 22:52:09'),(328,287,1,'2010-06-12 08:38:56'),(89,128,9,'2010-05-20 22:52:57'),(104,153,1,'2010-05-25 18:35:25'),(91,129,9,'2010-05-20 22:55:25'),(92,130,9,'2010-05-20 22:57:07'),(355,109,3,'2010-06-14 14:43:31'),(98,112,1,'2010-05-22 19:16:18'),(170,156,2,'2010-06-03 19:25:37'),(101,142,1,'2010-05-24 04:18:22'),(131,103,1,'2010-05-28 23:11:55'),(329,214,1,'2010-06-12 13:51:02'),(513,444,1,'2010-08-13 10:50:13'),(134,175,1,'2010-06-01 18:24:28'),(173,156,4,'2010-06-03 19:57:46'),(169,156,1,'2010-06-03 19:16:56'),(142,178,1,'2010-06-01 21:24:46'),(143,178,2,'2010-06-01 21:32:27'),(524,480,1,'2010-08-25 21:34:27'),(168,184,1,'2010-06-03 16:54:12'),(318,284,1,'2010-06-11 18:32:01'),(322,282,4,'2010-06-11 18:56:21'),(174,156,5,'2010-06-03 20:15:33'),(175,156,6,'2010-06-03 20:20:40'),(176,156,7,'2010-06-03 20:22:39'),(239,213,1,'2010-06-09 13:51:58'),(284,262,1,'2010-06-10 20:02:05'),(353,109,1,'2010-06-14 14:02:34'),(238,187,1,'2010-06-08 23:42:13'),(223,199,1,'2010-06-08 01:58:10'),(190,176,1,'2010-06-03 22:51:30'),(214,188,1,'2010-06-05 20:08:23'),(508,94,1,'2010-08-11 22:44:34'),(217,192,1,'2010-06-06 22:27:44'),(512,101,1,'2010-08-13 03:01:35'),(319,282,3,'2010-06-11 18:39:34'),(247,221,1,'2010-06-09 18:37:41'),(330,290,1,'2010-06-12 18:11:53'),(249,229,1,'2010-06-09 21:18:01'),(250,195,1,'2010-06-10 01:36:03'),(251,235,1,'2010-06-10 12:34:44'),(252,216,1,'2010-06-10 15:05:01'),(253,219,1,'2010-06-10 15:31:05'),(254,206,1,'2010-06-10 15:31:07'),(255,215,1,'2010-06-10 15:31:38'),(257,207,1,'2010-06-10 15:31:58'),(258,211,1,'2010-06-10 15:32:07'),(259,237,1,'2010-06-10 15:32:14'),(260,241,1,'2010-06-10 15:33:38'),(261,239,1,'2010-06-10 15:33:39'),(262,240,1,'2010-06-10 15:34:09'),(263,242,1,'2010-06-10 15:34:27'),(264,244,1,'2010-06-10 15:34:30'),(265,243,1,'2010-06-10 15:35:29'),(266,247,1,'2010-06-10 15:35:41'),(267,134,1,'2010-06-10 15:36:05'),(268,245,1,'2010-06-10 15:36:13'),(269,246,1,'2010-06-10 15:36:26'),(307,248,1,'2010-06-11 13:26:34'),(278,249,1,'2010-06-10 18:19:53'),(272,253,1,'2010-06-10 15:43:19'),(273,254,1,'2010-06-10 15:45:47'),(274,226,1,'2010-06-10 15:59:32'),(275,256,1,'2010-06-10 16:00:51'),(276,258,1,'2010-06-10 17:28:18'),(523,201,1,'2010-08-23 04:38:37'),(279,259,1,'2010-06-10 18:36:07'),(280,260,1,'2010-06-10 18:52:55'),(281,261,1,'2010-06-10 19:15:24'),(282,108,1,'2010-06-10 19:20:45'),(290,263,1,'2010-06-10 21:20:05'),(291,236,1,'2010-06-10 21:42:08'),(292,227,1,'2010-06-10 21:49:07'),(321,282,9,'2010-06-11 18:43:05'),(295,221,2,'2010-06-10 21:55:29'),(296,236,2,'2010-06-10 21:55:54'),(316,282,1,'2010-06-11 18:06:19'),(298,236,9,'2010-06-10 22:04:29'),(299,221,9,'2010-06-10 22:04:36'),(532,493,1,'2010-08-30 23:23:24'),(301,99,2,'2010-06-10 22:12:00'),(302,99,3,'2010-06-10 22:16:10'),(303,99,9,'2010-06-10 22:18:15'),(315,281,1,'2010-06-11 18:05:44'),(338,208,1,'2010-06-13 22:35:04'),(306,163,1,'2010-06-10 23:40:41'),(308,204,1,'2010-06-11 14:03:06'),(309,264,1,'2010-06-11 15:32:21'),(310,277,1,'2010-06-11 16:01:58'),(312,280,1,'2010-06-11 17:08:29'),(511,442,1,'2010-08-12 18:00:32'),(324,282,8,'2010-06-11 18:59:23'),(510,441,1,'2010-08-12 14:59:21'),(331,293,1,'2010-06-12 19:10:08'),(332,291,1,'2010-06-12 19:10:21'),(333,292,1,'2010-06-12 19:13:50'),(334,295,1,'2010-06-12 19:23:18'),(382,316,1,'2010-06-19 21:36:21'),(336,285,1,'2010-06-12 20:50:38'),(358,109,7,'2010-06-14 15:05:12'),(357,109,4,'2010-06-14 14:49:07'),(507,271,1,'2010-08-11 12:30:03'),(506,435,1,'2010-08-09 19:13:26'),(366,304,1,'2010-06-15 23:05:13'),(367,202,1,'2010-06-16 14:07:33'),(398,341,1,'2010-06-25 04:10:54'),(427,0,2,'2010-07-06 15:09:20'),(383,323,1,'2010-06-21 19:00:20'),(435,310,1,'2010-07-07 21:16:42'),(372,311,1,'2010-06-17 23:43:42'),(373,311,2,'2010-06-17 23:49:40'),(385,328,1,'2010-06-22 21:41:38'),(387,330,1,'2010-06-23 13:37:35'),(388,333,1,'2010-06-23 20:23:05'),(399,357,1,'2010-06-29 13:14:38'),(400,314,1,'2010-06-30 15:02:07'),(401,98,19,'2010-06-30 23:15:25'),(402,361,1,'2010-07-01 23:41:21'),(403,361,2,'2010-07-02 00:25:58'),(404,362,1,'2010-07-02 21:43:29'),(405,362,2,'2010-07-02 21:48:50'),(407,369,1,'2010-07-06 07:55:54'),(409,368,1,'2010-07-06 14:28:10'),(410,371,1,'2010-07-06 14:32:00'),(411,375,1,'2010-07-06 14:32:36'),(412,373,1,'2010-07-06 14:33:01'),(426,378,9,'2010-07-06 15:09:12'),(414,372,1,'2010-07-06 14:34:16'),(415,374,1,'2010-07-06 14:35:54'),(425,373,9,'2010-07-06 15:09:11'),(417,376,1,'2010-07-06 14:38:36'),(583,107,1,'2010-09-07 10:09:06'),(419,375,2,'2010-07-06 14:44:49'),(420,375,3,'2010-07-06 14:49:53'),(421,0,1,'2010-07-06 14:59:25'),(422,373,2,'2010-07-06 15:02:33'),(428,374,2,'2010-07-06 15:09:24'),(429,378,1,'2010-07-06 15:12:57'),(430,378,4,'2010-07-06 15:16:26'),(431,373,4,'2010-07-06 15:16:47'),(432,378,8,'2010-07-06 15:18:27'),(433,373,8,'2010-07-06 15:25:49'),(434,379,1,'2010-07-06 22:04:19'),(436,326,1,'2010-07-10 20:28:12'),(437,385,1,'2010-07-12 03:45:44'),(439,233,1,'2010-07-13 22:13:53'),(440,394,1,'2010-07-20 14:51:10'),(441,396,1,'2010-07-20 14:53:53'),(456,395,1,'2010-07-21 15:05:25'),(444,396,2,'2010-07-20 15:04:30'),(445,396,3,'2010-07-20 15:10:36'),(446,394,2,'2010-07-20 15:11:20'),(447,396,9,'2010-07-20 15:11:54'),(448,394,3,'2010-07-20 15:13:32'),(449,394,9,'2010-07-20 15:15:16'),(450,396,4,'2010-07-20 15:24:57'),(451,394,4,'2010-07-20 15:25:17'),(452,394,8,'2010-07-20 15:26:23'),(453,396,8,'2010-07-20 15:27:00'),(457,403,1,'2010-07-22 18:22:43'),(458,404,1,'2010-07-23 17:17:44'),(474,419,1,'2010-08-02 22:04:31'),(467,412,1,'2010-07-29 08:32:39'),(468,412,21,'2010-07-29 08:34:07'),(469,412,22,'2010-07-29 08:34:37'),(470,415,1,'2010-07-30 17:27:30'),(475,419,23,'2010-08-02 22:09:28'),(476,419,24,'2010-08-02 22:10:12'),(477,420,1,'2010-08-03 14:21:56'),(614,519,1,'2010-09-13 09:38:02'),(497,423,1,'2010-08-04 14:52:21'),(496,425,9,'2010-08-04 14:45:59'),(492,428,1,'2010-08-04 14:26:33'),(495,425,3,'2010-08-04 14:45:05'),(494,427,9,'2010-08-04 14:44:38'),(484,421,1,'2010-08-04 02:28:35'),(486,427,1,'2010-08-04 14:16:28'),(487,426,1,'2010-08-04 14:16:32'),(488,425,1,'2010-08-04 14:20:06'),(493,425,2,'2010-08-04 14:36:23'),(600,507,1,'2010-09-10 00:46:48'),(491,424,1,'2010-08-04 14:21:54'),(499,427,4,'2010-08-04 14:59:22'),(500,427,8,'2010-08-04 15:01:07'),(578,429,1,'2010-09-02 16:08:52'),(582,450,1,'2010-09-03 09:52:00'),(631,100,1,'2010-09-29 20:46:08'),(505,433,1,'2010-08-07 18:13:13'),(515,445,1,'2010-08-13 13:29:09'),(516,448,1,'2010-08-14 10:13:16'),(517,451,1,'2010-08-14 23:05:12'),(518,135,1,'2010-08-15 19:31:15'),(519,456,1,'2010-08-16 08:35:53'),(520,461,1,'2010-08-16 10:30:55'),(522,457,1,'2010-08-23 03:58:36'),(528,278,1,'2010-08-28 13:27:18'),(529,485,1,'2010-08-28 18:08:39'),(533,110,1,'2010-08-30 23:30:31'),(615,520,1,'2010-09-13 14:24:55'),(622,531,1,'2010-09-21 05:33:49'),(623,533,1,'2010-09-22 03:06:33'),(628,535,1,'2010-09-22 15:11:21'),(627,534,1,'2010-09-22 15:11:12'),(629,534,2,'2010-09-22 15:16:06'),(630,535,2,'2010-09-22 15:16:08'),(632,540,1,'2010-10-01 04:03:21'),(633,554,1,'2010-10-02 22:32:48'),(634,536,1,'2010-10-04 14:38:43'),(635,555,1,'2010-10-04 15:12:25');
/*!40000 ALTER TABLE `159_player_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `159_player_state_changes`
--

DROP TABLE IF EXISTS `159_player_state_changes`;
CREATE TABLE `159_player_state_changes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `event_type` enum('VIEW_ITEM','VIEW_NODE','VIEW_NPC') collate utf8_unicode_ci NOT NULL,
  `event_detail` varchar(50) collate utf8_unicode_ci default NULL,
  `action` enum('GIVE_ITEM','TAKE_ITEM') collate utf8_unicode_ci NOT NULL,
  `action_detail` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `159_player_state_changes`
--

LOCK TABLES `159_player_state_changes` WRITE;
/*!40000 ALTER TABLE `159_player_state_changes` DISABLE KEYS */;
INSERT INTO `159_player_state_changes` VALUES (8,'VIEW_ITEM','4','GIVE_ITEM',8),(2,'VIEW_NODE','6','GIVE_ITEM',2),(3,'VIEW_NODE','22','GIVE_ITEM',3),(4,'VIEW_NODE','23','GIVE_ITEM',4),(7,'VIEW_NODE','26','GIVE_ITEM',7),(9,'VIEW_NODE','10','GIVE_ITEM',9),(10,'VIEW_NODE','29','GIVE_ITEM',1);
/*!40000 ALTER TABLE `159_player_state_changes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `159_qrcodes`
--

DROP TABLE IF EXISTS `159_qrcodes`;
CREATE TABLE `159_qrcodes` (
  `qrcode_id` int(11) NOT NULL auto_increment,
  `link_type` enum('Location') collate utf8_unicode_ci NOT NULL default 'Location',
  `link_id` int(11) NOT NULL,
  `code` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`qrcode_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `159_qrcodes`
--

LOCK TABLES `159_qrcodes` WRITE;
/*!40000 ALTER TABLE `159_qrcodes` DISABLE KEYS */;
INSERT INTO `159_qrcodes` VALUES (15,'Location',15,'102'),(2,'Location',2,'3537'),(3,'Location',3,'5425'),(4,'Location',4,'1265'),(5,'Location',5,'3372'),(6,'Location',6,'3657'),(7,'Location',7,'7142'),(8,'Location',8,'7175'),(9,'Location',9,'1645'),(10,'Location',10,'2332'),(11,'Location',11,'2157'),(12,'Location',12,'2112'),(13,'Location',13,'5636'),(14,'Location',14,'1143'),(16,'Location',16,'16'),(17,'Location',17,'17'),(18,'Location',18,'18'),(19,'Location',19,'19'),(20,'Location',20,'20'),(21,'Location',21,'21'),(22,'Location',22,'22'),(29,'Location',1,'3421'),(25,'Location',25,'25'),(23,'Location',23,'23'),(24,'Location',24,'24');
/*!40000 ALTER TABLE `159_qrcodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `159_quests`
--

DROP TABLE IF EXISTS `159_quests`;
CREATE TABLE `159_quests` (
  `quest_id` int(11) unsigned NOT NULL auto_increment,
  `name` tinytext collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `text_when_complete` tinytext collate utf8_unicode_ci NOT NULL COMMENT 'This is the txt that displays on the completed quests screen',
  `icon_media_id` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`quest_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `159_quests`
--

LOCK TABLES `159_quests` WRITE;
/*!40000 ALTER TABLE `159_quests` DISABLE KEYS */;
INSERT INTO `159_quests` VALUES (1,'Dow Day','The day is October 18th, 1967. The place is the politically charged campus of the University of Wisconsin. You are a reporter working for the Capitol Times and your job is to investigate the Dow protests and write an article for the evening paper.','',0),(5,'Part 2','This part of Dow Day takes place in and around the Commerce building. Make your way there to find out more about the situation. Oh yeah, you should know that the Commerce building was renamed sometime after 1967 - it is now called Ingraham Hall.','',0),(2,'See your editor','Your editor sees you crossing the street and comes to meet you in front of the Memorial Union. He looks very hurried and is speaking quickly.','',0),(3,'See the recruiter','Your editor wants you to interview the Dow recruiter across the street.','',0),(4,'See the Chancellor','Your editor wants you to go up to Bascom Hall to talk with the Chancellor. Maybe you\'ll pick up some interviews along the way as well.','Well, you didn\'t get in to the Chancellor, but the Dean\'s remarks will do the job.',0),(6,'More interviews','Things look like they\'re blowing up around you. Keep working to get people\'s stories.	','',0),(7,'Find out about Madison Police','It\'s really unusual, but the Madison police are showing up. You think you see the chief. See if you can talk to him about his presence on campus.','',0),(8,'Talk with student leader','It looks like a student leader is exiting Bascom Hall. Go ask him if he was able to work anything out with the Chancellor. ','',0),(9,'Police enter Commerce','There is a giant clamor back at Commerce. The police are entering the building.','',0),(10,'Get back','The situation has degenerated greatly. Go meet your editor in front of Bascom Hall before you get caught up in the violence.','Hey you made it out of there! Head to the front steps of the Union. After you regroup, you\'ll write up your story for tomorrow\'s paper.	',0),(11,'Go outside','The noise outside has gotten louder. Exit the building to the north to continue the game.','',0);
/*!40000 ALTER TABLE `159_quests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `159_requirements`
--

DROP TABLE IF EXISTS `159_requirements`;
CREATE TABLE `159_requirements` (
  `requirement_id` int(11) NOT NULL auto_increment,
  `content_type` enum('Node','QuestDisplay','QuestComplete','Location') collate utf8_unicode_ci NOT NULL,
  `content_id` int(10) unsigned NOT NULL,
  `requirement` enum('PLAYER_HAS_ITEM','PLAYER_DOES_NOT_HAVE_ITEM','PLAYER_VIEWED_ITEM','PLAYER_HAS_NOT_VIEWED_ITEM','PLAYER_VIEWED_NODE','PLAYER_HAS_NOT_VIEWED_NODE','PLAYER_VIEWED_NPC','PLAYER_HAS_NOT_VIEWED_NPC','PLAYER_HAS_UPLOADED_MEDIA_ITEM') collate utf8_unicode_ci NOT NULL,
  `requirement_detail_1` varchar(30) collate utf8_unicode_ci default NULL,
  `requirement_detail_2` varchar(30) collate utf8_unicode_ci default NULL,
  `requirement_detail_3` varchar(30) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`requirement_id`)
) ENGINE=MyISAM AUTO_INCREMENT=117 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `159_requirements`
--

LOCK TABLES `159_requirements` WRITE;
/*!40000 ALTER TABLE `159_requirements` DISABLE KEYS */;
INSERT INTO `159_requirements` VALUES (1,'Location',3,'PLAYER_VIEWED_NPC','1',NULL,NULL),(2,'Location',4,'PLAYER_VIEWED_NPC','2',NULL,NULL),(3,'Location',5,'PLAYER_VIEWED_NPC','3',NULL,NULL),(4,'Location',6,'PLAYER_VIEWED_NPC','3',NULL,NULL),(5,'Location',22,'PLAYER_VIEWED_NPC','3',NULL,NULL),(6,'Location',16,'PLAYER_VIEWED_NODE','23',NULL,NULL),(7,'Location',8,'PLAYER_VIEWED_NODE','24',NULL,NULL),(8,'Location',9,'PLAYER_VIEWED_NODE','24',NULL,NULL),(9,'Location',10,'PLAYER_VIEWED_NPC','10',NULL,NULL),(10,'Location',11,'PLAYER_VIEWED_ITEM','5',NULL,NULL),(11,'Location',12,'PLAYER_VIEWED_NPC','11',NULL,NULL),(12,'Location',17,'PLAYER_VIEWED_ITEM','6',NULL,NULL),(13,'Location',20,'PLAYER_VIEWED_NODE','18',NULL,NULL),(14,'Location',21,'PLAYER_VIEWED_NODE','18',NULL,NULL),(15,'Location',13,'PLAYER_VIEWED_NODE','26',NULL,NULL),(16,'Location',14,'PLAYER_VIEWED_NODE','18',NULL,NULL),(17,'Location',2,'PLAYER_HAS_NOT_VIEWED_NPC','2',NULL,NULL),(18,'Location',3,'PLAYER_HAS_NOT_VIEWED_NPC','3',NULL,NULL),(19,'Location',4,'PLAYER_HAS_NOT_VIEWED_NPC','6',NULL,NULL),(20,'Location',5,'PLAYER_HAS_NOT_VIEWED_NPC','6',NULL,NULL),(21,'Location',6,'PLAYER_HAS_NOT_VIEWED_NPC','6',NULL,NULL),(22,'Location',7,'PLAYER_HAS_NOT_VIEWED_NODE','28',NULL,NULL),(23,'Location',16,'PLAYER_HAS_NOT_VIEWED_NPC','9',NULL,NULL),(24,'Location',8,'PLAYER_HAS_NOT_VIEWED_NPC','10',NULL,NULL),(25,'Location',9,'PLAYER_HAS_NOT_VIEWED_NPC','11',NULL,NULL),(26,'Location',10,'PLAYER_HAS_NOT_VIEWED_NPC','13',NULL,NULL),(27,'Location',11,'PLAYER_HAS_NOT_VIEWED_NODE','25',NULL,NULL),(28,'Location',12,'PLAYER_HAS_NOT_VIEWED_NPC','12',NULL,NULL),(116,'Location',22,'PLAYER_HAS_NOT_VIEWED_NPC','7',NULL,NULL),(95,'Location',24,'PLAYER_VIEWED_NPC','12',NULL,NULL),(31,'QuestComplete',2,'PLAYER_VIEWED_NPC','1',NULL,NULL),(32,'QuestDisplay',3,'PLAYER_VIEWED_NPC','1',NULL,NULL),(33,'QuestDisplay',4,'PLAYER_VIEWED_NPC','1',NULL,NULL),(34,'QuestComplete',3,'PLAYER_VIEWED_NPC','2',NULL,NULL),(35,'QuestComplete',4,'PLAYER_VIEWED_NPC','6',NULL,NULL),(36,'QuestDisplay',5,'PLAYER_HAS_NOT_VIEWED_NODE','24',NULL,NULL),(37,'QuestComplete',6,'PLAYER_VIEWED_NPC','13',NULL,NULL),(38,'QuestDisplay',5,'PLAYER_VIEWED_NPC','6',NULL,NULL),(39,'QuestDisplay',6,'PLAYER_VIEWED_NODE','24',NULL,NULL),(40,'QuestDisplay',1,'PLAYER_HAS_NOT_VIEWED_NPC','1',NULL,NULL),(41,'Location',18,'PLAYER_VIEWED_NODE','25',NULL,NULL),(42,'Location',19,'PLAYER_VIEWED_NODE','17',NULL,NULL),(43,'Location',7,'PLAYER_VIEWED_NPC','6',NULL,NULL),(44,'Location',14,'PLAYER_HAS_NOT_VIEWED_NODE','21',NULL,NULL),(45,'Location',15,'PLAYER_HAS_NOT_VIEWED_NODE','24',NULL,NULL),(46,'Location',15,'PLAYER_VIEWED_NPC','6',NULL,NULL),(47,'Location',17,'PLAYER_HAS_NOT_VIEWED_NODE','25',NULL,NULL),(48,'Location',18,'PLAYER_HAS_NOT_VIEWED_NODE','17',NULL,NULL),(49,'Location',19,'PLAYER_HAS_NOT_VIEWED_NODE','18',NULL,NULL),(50,'Location',20,'PLAYER_HAS_NOT_VIEWED_NODE','27',NULL,NULL),(51,'Location',21,'PLAYER_HAS_NOT_VIEWED_NPC','14',NULL,NULL),(52,'Location',13,'PLAYER_HAS_NOT_VIEWED_NODE','21',NULL,NULL),(54,'Location',1,'PLAYER_DOES_NOT_HAVE_ITEM','1',NULL,NULL),(96,'Location',24,'PLAYER_HAS_NOT_VIEWED_ITEM','6',NULL,NULL),(94,'Location',23,'PLAYER_HAS_NOT_VIEWED_ITEM','5',NULL,NULL),(93,'Location',23,'PLAYER_VIEWED_NPC','13',NULL,NULL),(92,'Location',25,'PLAYER_HAS_NOT_VIEWED_NODE','23',NULL,NULL),(59,'QuestComplete',1,'PLAYER_VIEWED_NPC','6',NULL,NULL),(60,'Location',1,'PLAYER_HAS_NOT_VIEWED_NODE','29',NULL,NULL),(97,'QuestDisplay',7,'PLAYER_VIEWED_NPC','13',NULL,NULL),(105,'QuestDisplay',2,'PLAYER_HAS_NOT_VIEWED_NODE','21',NULL,NULL),(63,'Node',1,'PLAYER_HAS_NOT_VIEWED_NODE','1',NULL,NULL),(64,'Node',2,'PLAYER_HAS_NOT_VIEWED_NODE','2',NULL,NULL),(65,'Node',3,'PLAYER_HAS_NOT_VIEWED_NODE','3',NULL,NULL),(66,'Node',4,'PLAYER_HAS_NOT_VIEWED_NODE','4',NULL,NULL),(67,'Node',6,'PLAYER_HAS_NOT_VIEWED_NODE','6',NULL,NULL),(68,'Node',7,'PLAYER_HAS_NOT_VIEWED_NODE','7',NULL,NULL),(69,'Node',8,'PLAYER_HAS_NOT_VIEWED_NODE','8',NULL,NULL),(70,'Node',9,'PLAYER_HAS_NOT_VIEWED_NODE','9',NULL,NULL),(71,'Node',10,'PLAYER_HAS_NOT_VIEWED_NODE','10',NULL,NULL),(72,'Node',11,'PLAYER_HAS_NOT_VIEWED_NODE','11',NULL,NULL),(73,'Node',12,'PLAYER_HAS_NOT_VIEWED_NODE','12',NULL,NULL),(74,'Node',13,'PLAYER_HAS_NOT_VIEWED_NODE','13',NULL,NULL),(75,'Node',14,'PLAYER_HAS_NOT_VIEWED_NODE','14',NULL,NULL),(76,'Node',15,'PLAYER_HAS_NOT_VIEWED_NODE','15',NULL,NULL),(77,'Node',16,'PLAYER_HAS_NOT_VIEWED_NODE','16',NULL,NULL),(78,'Node',17,'PLAYER_HAS_NOT_VIEWED_NODE','17',NULL,NULL),(79,'Node',18,'PLAYER_HAS_NOT_VIEWED_NODE','18',NULL,NULL),(80,'Node',19,'PLAYER_HAS_NOT_VIEWED_NODE','19',NULL,NULL),(81,'Node',20,'PLAYER_HAS_NOT_VIEWED_NODE','20',NULL,NULL),(82,'Node',21,'PLAYER_HAS_NOT_VIEWED_NODE','21',NULL,NULL),(83,'Node',22,'PLAYER_HAS_NOT_VIEWED_NPC','7',NULL,NULL),(84,'Node',23,'PLAYER_HAS_NOT_VIEWED_NODE','23',NULL,NULL),(85,'Node',24,'PLAYER_HAS_NOT_VIEWED_NODE','24',NULL,NULL),(86,'Node',25,'PLAYER_HAS_NOT_VIEWED_NODE','25',NULL,NULL),(87,'Node',26,'PLAYER_HAS_NOT_VIEWED_NODE','26',NULL,NULL),(88,'Node',27,'PLAYER_HAS_NOT_VIEWED_NODE','27',NULL,NULL),(91,'Location',25,'PLAYER_VIEWED_NPC','6',NULL,NULL),(90,'Node',29,'PLAYER_HAS_NOT_VIEWED_NODE','29',NULL,NULL),(98,'QuestComplete',7,'PLAYER_VIEWED_NPC','12',NULL,NULL),(99,'QuestDisplay',8,'PLAYER_VIEWED_NPC','11',NULL,NULL),(100,'QuestComplete',8,'PLAYER_VIEWED_NPC','13',NULL,NULL),(101,'QuestDisplay',9,'PLAYER_VIEWED_NPC','12',NULL,NULL),(102,'QuestComplete',9,'PLAYER_VIEWED_ITEM','6',NULL,NULL),(103,'QuestDisplay',10,'PLAYER_VIEWED_NODE','18',NULL,NULL),(104,'QuestComplete',10,'PLAYER_VIEWED_NODE','21',NULL,NULL),(106,'QuestDisplay',3,'PLAYER_HAS_NOT_VIEWED_NODE','21',NULL,NULL),(107,'QuestDisplay',4,'PLAYER_HAS_NOT_VIEWED_NODE','21',NULL,NULL),(108,'QuestDisplay',6,'PLAYER_HAS_NOT_VIEWED_NODE','21',NULL,NULL),(109,'QuestDisplay',7,'PLAYER_HAS_NOT_VIEWED_NODE','21',NULL,NULL),(110,'QuestDisplay',8,'PLAYER_HAS_NOT_VIEWED_NODE','21',NULL,NULL),(111,'QuestDisplay',9,'PLAYER_HAS_NOT_VIEWED_NODE','21',NULL,NULL),(112,'QuestComplete',5,'PLAYER_VIEWED_NODE','24',NULL,NULL),(113,'QuestDisplay',11,'PLAYER_VIEWED_NODE','23',NULL,NULL),(114,'QuestComplete',11,'PLAYER_VIEWED_NODE','24',NULL,NULL),(115,'QuestDisplay',11,'PLAYER_HAS_NOT_VIEWED_NODE','24',NULL,NULL);
/*!40000 ALTER TABLE `159_requirements` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-10-04 17:54:50
